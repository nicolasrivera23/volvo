package com.codoacodo.entity;

/**
 *
 * @author Nicolas
 */
public class Vehiculo {
    
    private Long id;
    private String marca;
    private String modelo;
    private int velocidadMaxima;
    private int velocidad;
    private boolean encendido;
    
    //Dos constructores, uno para los datos
    //que necesito para el insert
    public Vehiculo(
            String marca,
            String modelo,
            int velocidadMaxima,
            int velocidad,
            boolean encendido) {
        this.marca = marca;
        this.modelo = modelo;
        this.velocidadMaxima = velocidadMaxima;
        this.velocidad = velocidad;
        this.encendido = encendido;
    }
    
    public Vehiculo(
            Long id,
            String marca,
            String modelo,
            int velocidadMaxima,
            int velocidad,
            boolean encendido) {
        this.id = id;
        this.marca = marca;
        this.modelo = modelo;
        this.velocidadMaxima = velocidadMaxima;
        this.velocidad = velocidad;
        this.encendido = encendido;
    }
    
    public void arrancar() {
        
        if(encendido = false) {
            this.encendido = true;
        } else {
            System.out.println(
            "El vehiculo ya se encuentra encendido"
            );
        }
    }
    
    public void acelerar() {
        if(encendido) {
            this.velocidad++;
        } else {
            System.out.println("Para acelerar el auto tiene que estar encendido");
        }
        
    }
    
    public void frenar() {
        if(this.velocidad > 0){
            this.velocidad--;
        } else {
            System.out.println(""
                    + "Para frenar se necesita una velocidad mayor a cero");
        }
        
    }
    
    public void apagar() {

        if(this.encendido = true && this.velocidad == 0) {
            this.encendido = false;
        } else {
            System.out.println("Frene primero antes de apagar el motor");
        }
    }

    @Override
    public String toString() {
        return "Vehiculo{" + "id=" + id + ", marca=" + marca + ", modelo=" + modelo + ", velocidadMaxima=" + velocidadMaxima + ", velocidad=" + velocidad + ", encendido=" + encendido + '}';
    }
    
    
    
}
