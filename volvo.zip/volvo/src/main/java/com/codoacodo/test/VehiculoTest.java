/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.codoacodo.test;

import com.codoacodo.entity.Vehiculo;

/**
 *
 * @author Nicolas
 */
public class VehiculoTest {
    
    public static void main(String[] args) {
        Vehiculo v1 = new Vehiculo(1L, "volkswagen", "amarok", 150, 0, false);
        System.out.println(v1);
        
        //v1.marca = "Volvo";
        
        
    }
    
}
